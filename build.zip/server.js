"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const typedi_1 = require("typedi");
const dotenv = __importStar(require("dotenv"));
const express_1 = __importDefault(require("express"));
const routing_controllers_1 = require("routing-controllers");
const transaction_controller_1 = require("./controllers/transaction.controller");
const transaction_sync_controller_1 = require("./controllers/transaction-sync.controller");
const logger_1 = require("./common/logger/logger");
const db_1 = require("./config/db");
const webhook_controller_1 = require("./controllers/webhook.controller");
const { defaultMetadataStorage } = require("class-transformer/storage");
(0, routing_controllers_1.useContainer)(typedi_1.Container);
dotenv.config({ path: __dirname + "/./../.env" });
typedi_1.Container.set(logger_1.Logger, new logger_1.Logger());
typedi_1.Container.set(db_1.SqlConnection, new db_1.SqlConnection());
const routingControllersOptions = {
    cors: true,
    classTransformer: true,
    routePrefix: "/api",
    controllers: [
        transaction_sync_controller_1.TransactionSyncController,
        transaction_controller_1.TransactionController,
        webhook_controller_1.WebhookController,
    ],
    authorizationChecker: async (action, roles) => {
        const token = action.request.headers["x-api-key"];
        if (!token)
            return false;
        if (token === process.env.WRITE_KEY_ROLE &&
            roles.find((role) => role === "WRITE")) {
            return true;
        }
        if (token === process.env.READ_KEY_ROLE && !roles.length) {
            return true;
        }
        return false;
    },
};
// const schemas = validationMetadatasToSchemas({
//   classTransformerMetadataStorage: defaultMetadataStorage,
//   refPointerPrefix: "#/components/schemas/",
// });
// const storage = getMetadataArgsStorage();
// const spec = routingControllersToSpec(storage, routingControllersOptions, {
//   components: {
//     schemas,
//     securitySchemes: {
//       basicAuth: { scheme: "basic", type: "http" },
//     },
//   },
//   info: {
//     description: "Generated with `routing-controllers-openapi`",
//     title: "My Node API Scaffold",
//     version: "1.0.0",
//   },
// });
if (!process.env.PORT) {
    process.exit(1);
}
const PORT = parseInt(process.env.PORT, 10);
const app = (0, routing_controllers_1.createExpressServer)(routingControllersOptions);
app.use(express_1.default.json());
// app.use("/docs", swaggerUi.serve, swaggerUi.setup(spec));
// app.get("/", (_req: any, res: { json: (arg0: OpenAPIObject) => void }) => {
//   res.json(spec);
// });
const server = app.listen(PORT, () => {
    console.log(`http://localhost:${PORT}`);
});
//# sourceMappingURL=server.js.map