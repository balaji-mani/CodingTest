"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CollectAtArrivalRepo = void 0;
const typedi_1 = require("typedi");
const db_1 = require("../config/db");
const collect_at_arrival_model_1 = require("../models/transaction-sync/collect-at-arrival.model");
let CollectAtArrivalRepo = class CollectAtArrivalRepo {
    constructor(connection) {
        this.connection = connection;
        this.repository =
            connection.dbConnection.getRepository(collect_at_arrival_model_1.CollectAtArrivalData);
    }
    async getByPhoneNumber(phone, pagingParam) {
        const results = await this.repository.find({
            order: {
                dtCreated: "ASC",
            },
            where: {
                customerMobileNo: phone,
            },
            skip: ((pagingParam === null || pagingParam === void 0 ? void 0 : pagingParam.pageNumber) || 0) * ((pagingParam === null || pagingParam === void 0 ? void 0 : pagingParam.pageSize) || 20),
            take: pagingParam === null || pagingParam === void 0 ? void 0 : pagingParam.pageSize,
        });
        return results;
    }
    async getByReceiptNo(id) {
        const result = await this.repository.findOne({ receiptNo: id });
        return result;
    }
    async addCollectAtArrival(addCollectAtArrival) {
        const returnResponse = [];
        for (let collection = 0; collection < addCollectAtArrival.length; collection++) {
            if (!addCollectAtArrival[collection].dtCreated) {
                addCollectAtArrival[collection].dtCreated = new Date();
            }
            if (!addCollectAtArrival[collection].dtUpdated) {
                addCollectAtArrival[collection].dtUpdated = new Date();
            }
        }
        const result = await this.repository.save(addCollectAtArrival);
        return result;
    }
    async getCountByPhoneNumber(phone) {
        const count = await this.repository.count({
            customerMobileNo: phone,
        });
        return count;
    }
};
CollectAtArrivalRepo = __decorate([
    (0, typedi_1.Service)(),
    __metadata("design:paramtypes", [db_1.SqlConnection])
], CollectAtArrivalRepo);
exports.CollectAtArrivalRepo = CollectAtArrivalRepo;
//# sourceMappingURL=collect-at-arrival.repo.js.map