"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesEntryRepo = void 0;
const typedi_1 = require("typedi");
const db_1 = require("../config/db");
const sales_entry_model_1 = require("../models/transaction-sync/sales-entry.model");
let SalesEntryRepo = class SalesEntryRepo {
    constructor(connection) {
        this.connection = connection;
        this.repository = connection.dbConnection.getRepository(sales_entry_model_1.SalesEntryData);
    }
    async getByReceiptNo(id) {
        const result = await this.repository.find({ receiptNo: id });
        return result;
    }
    async addSalesEntryRepo(addSalesEntryData) {
        for (let collection = 0; collection < addSalesEntryData.length; collection++) {
            if (!addSalesEntryData[collection].dtCreated) {
                addSalesEntryData[collection].dtCreated = new Date();
            }
            if (!addSalesEntryData[collection].dtUpdated) {
                addSalesEntryData[collection].dtUpdated = new Date();
            }
        }
        const result = await this.repository.save(addSalesEntryData);
        return result;
    }
};
SalesEntryRepo = __decorate([
    (0, typedi_1.Service)(),
    __metadata("design:paramtypes", [db_1.SqlConnection])
], SalesEntryRepo);
exports.SalesEntryRepo = SalesEntryRepo;
//# sourceMappingURL=sales-entry.repo.js.map