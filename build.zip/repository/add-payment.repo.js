"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentRepo = void 0;
const typedi_1 = require("typedi");
const db_1 = require("../config/db");
const transaction_sync_payment_entry_model_1 = require("../models/transaction-sync/transaction-sync-payment-entry.model");
let PaymentRepo = class PaymentRepo {
    constructor(connection) {
        this.connection = connection;
        this.repository = connection.dbConnection.getRepository(transaction_sync_payment_entry_model_1.PaymentEntryData);
    }
    async getByReceiptNo(receiptNo) {
        const result = await this.repository.find({ "receiptNo": receiptNo });
        return result;
    }
    async addPaymentENtry(paymentEntryData) {
        const returnResponse = [];
        for (let collection = 0; collection < paymentEntryData.length; collection++) {
            if (!paymentEntryData[collection].dtCreated) {
                paymentEntryData[collection].dtCreated = new Date();
            }
            if (!paymentEntryData[collection].dtUpdated) {
                paymentEntryData[collection].dtUpdated = new Date();
            }
            const result = await this.repository.save(paymentEntryData);
            const returnObject = {
                "data": (result[0])
            };
            returnResponse.push(returnObject);
        }
        return returnResponse;
    }
};
PaymentRepo = __decorate([
    typedi_1.Service(),
    __metadata("design:paramtypes", [db_1.SqlConnection])
], PaymentRepo);
exports.PaymentRepo = PaymentRepo;
//# sourceMappingURL=add-payment.repo.js.map