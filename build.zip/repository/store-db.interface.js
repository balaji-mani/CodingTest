"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=store-db.interface.js.map