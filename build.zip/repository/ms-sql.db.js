"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MsSqlDb = void 0;
const typeorm_1 = require("typeorm");
class MsSqlDb {
    constructor(connection, entity) {
        this.repository = connection.getRepository(entity);
    }
    getMany(queryParam) {
        throw new Error("Method not implemented.");
    }
    get(id) {
        throw new Error("Method not implemented.");
    }
    getAll() {
        throw new Error("Method not implemented.");
    }
    async add(newItem) {
        const entityManager = await typeorm_1.getManager();
        const currentDate = new Date().toISOString();
        newItem.dtCreated = new Date(currentDate);
        newItem.dtUpdated = new Date(currentDate);
        const response = await entityManager.save(newItem);
        return response;
    }
}
exports.MsSqlDb = MsSqlDb;
//# sourceMappingURL=ms-sql.db.js.map