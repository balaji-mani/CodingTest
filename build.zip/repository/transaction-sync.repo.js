"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionSyncRepo = void 0;
class TransactionSyncRepo {
    constructor() { }
}
exports.TransactionSyncRepo = TransactionSyncRepo;
//# sourceMappingURL=transaction-sync.repo.js.map