"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionRepo = void 0;
class TransactionRepo {
}
exports.TransactionRepo = TransactionRepo;
//# sourceMappingURL=transactions.repo.js.map