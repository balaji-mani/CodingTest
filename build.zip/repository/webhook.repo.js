"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookRepo = void 0;
const typedi_1 = require("typedi");
const db_1 = require("../config/db");
const webhook_model_1 = require("../models/webhook/webhook.model");
let WebhookRepo = class WebhookRepo {
    constructor(connection) {
        this.connection = connection;
        this.repository = connection.dbConnection.getRepository(webhook_model_1.WebhookData);
    }
    async getAll() {
        const result = await this.repository.find();
        return result;
    }
    async getByDomain(domainName) {
        const result = await this.repository.find({ domainName: domainName });
        return result;
    }
    async add(addWebhookData) {
        const existingDomainHooks = await this.getByDomain(addWebhookData.domainName);
        if (existingDomainHooks && existingDomainHooks.length > 0) {
            const result = await this.repository.update({
                id: existingDomainHooks[0].id,
            }, {
                webhookUrl: addWebhookData.webhookUrl,
                dtUpdated: new Date(),
            });
            return addWebhookData;
        }
        else {
            if (!addWebhookData.dtCreated) {
                addWebhookData.dtCreated = new Date();
            }
            if (!addWebhookData.dtUpdated) {
                addWebhookData.dtUpdated = new Date();
            }
            const result = await this.repository.save(addWebhookData);
            return result;
        }
    }
};
WebhookRepo = __decorate([
    (0, typedi_1.Service)(),
    __metadata("design:paramtypes", [db_1.SqlConnection])
], WebhookRepo);
exports.WebhookRepo = WebhookRepo;
//# sourceMappingURL=webhook.repo.js.map