"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionSyncController = void 0;
const routing_controllers_1 = require("routing-controllers");
const logger_1 = require("../common/logger/logger");
const transaction_sync_services_1 = require("../services/transaction-sync.services");
const base_controller_1 = require("./base.controller");
let TransactionSyncController = class TransactionSyncController extends base_controller_1.BaseController {
    constructor(transactionSyncService, logger) {
        super(logger);
        this.transactionSyncService = transactionSyncService;
    }
    async addCollectAtArrivals(collectAtArrivalData) {
        try {
            const result = await this.transactionSyncService.addCollectAtArrivals(collectAtArrivalData);
            return this.returnSuccess(result);
        }
        catch (error) {
            this.logger.error(error);
            return this.returnError(error);
        }
    }
    async addHeaders(headerData) {
        try {
            const result = await this.transactionSyncService.addHeaders(headerData);
            return this.returnSuccess(result);
        }
        catch (error) {
            this.logger.error(error);
            return this.returnError(error);
        }
    }
    async addPaymentEntries(paymentEntryData) {
        try {
            const result = await this.transactionSyncService.addPaymentEntries(paymentEntryData);
            return this.returnSuccess(result);
        }
        catch (error) {
            this.logger.error(error);
            return this.returnError(error);
        }
    }
    async addSalesEntries(salesEntryData) {
        try {
            const result = await this.transactionSyncService.addSalesEntries(salesEntryData);
            return this.returnSuccess(result);
        }
        catch (error) {
            this.logger.error(error);
            return this.returnError(error);
        }
    }
    async addFlightDetails(flightDetails) {
        try {
            const result = await this.transactionSyncService.addFlightDetails(flightDetails);
            return this.returnSuccess(result);
        }
        catch (error) {
            this.logger.error(error);
            return this.returnError(error);
        }
    }
    async addProductInfo(productInfo) {
        try {
            const result = await this.transactionSyncService.addProductInfo(productInfo);
            return this.returnSuccess(result);
        }
        catch (error) {
            this.logger.error(error);
            return this.returnError(error);
        }
    }
};
__decorate([
    (0, routing_controllers_1.Post)("/collect-at-arrivals"),
    __param(0, (0, routing_controllers_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array]),
    __metadata("design:returntype", Promise)
], TransactionSyncController.prototype, "addCollectAtArrivals", null);
__decorate([
    (0, routing_controllers_1.Post)("/header-entries"),
    __param(0, (0, routing_controllers_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array]),
    __metadata("design:returntype", Promise)
], TransactionSyncController.prototype, "addHeaders", null);
__decorate([
    (0, routing_controllers_1.Post)("/payment-entries"),
    __param(0, (0, routing_controllers_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array]),
    __metadata("design:returntype", Promise)
], TransactionSyncController.prototype, "addPaymentEntries", null);
__decorate([
    (0, routing_controllers_1.Post)("/sales-entries"),
    __param(0, (0, routing_controllers_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array]),
    __metadata("design:returntype", Promise)
], TransactionSyncController.prototype, "addSalesEntries", null);
__decorate([
    (0, routing_controllers_1.Post)("/flight-details"),
    __param(0, (0, routing_controllers_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array]),
    __metadata("design:returntype", Promise)
], TransactionSyncController.prototype, "addFlightDetails", null);
__decorate([
    (0, routing_controllers_1.Post)("/product-info"),
    __param(0, (0, routing_controllers_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array]),
    __metadata("design:returntype", Promise)
], TransactionSyncController.prototype, "addProductInfo", null);
TransactionSyncController = __decorate([
    (0, routing_controllers_1.JsonController)("/transaction-sync"),
    (0, routing_controllers_1.Authorized)('WRITE'),
    __metadata("design:paramtypes", [transaction_sync_services_1.TransactionSyncService, logger_1.Logger])
], TransactionSyncController);
exports.TransactionSyncController = TransactionSyncController;
//# sourceMappingURL=transaction-sync.controller.js.map