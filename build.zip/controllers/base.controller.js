"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseController = void 0;
class BaseController {
    constructor(logger) {
        this.logger = logger;
    }
    returnError(error) {
        return {
            status: 500,
            error: error,
        };
    }
    returnSuccess(data) {
        return {
            data: data,
            status: 200,
            // totalCount: count
        };
    }
}
exports.BaseController = BaseController;
//# sourceMappingURL=base.controller.js.map