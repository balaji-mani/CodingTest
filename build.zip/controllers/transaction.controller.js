"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionController = void 0;
const routing_controllers_1 = require("routing-controllers");
const logger_1 = require("../common/logger/logger");
const transaction_service_1 = require("../services/transaction.service");
const base_controller_1 = require("./base.controller");
const paging_params_model_1 = require("../models/paging-params.model");
const phone_query_param_model_1 = require("../models/phone-query-param.model");
let TransactionController = class TransactionController extends base_controller_1.BaseController {
    constructor(transactionService, logger) {
        super(logger);
        this.transactionService = transactionService;
    }
    async getByPhone(options) {
        try {
            const phoneNumer = options === null || options === void 0 ? void 0 : options.phone;
            if (!phoneNumer) {
                return this.returnError(new Error('phone is required'));
            }
            const requestOptionsData = new paging_params_model_1.PagingParams();
            if (options.pageNumber && options.pageSize) {
                requestOptionsData.pageNumber = options === null || options === void 0 ? void 0 : options.pageNumber;
                requestOptionsData.pageSize = options === null || options === void 0 ? void 0 : options.pageSize;
            }
            const transaction = await this.transactionService.getByPhone(phoneNumer, options);
            return this.returnSuccess(transaction);
        }
        catch (error) {
            this.logger.error(error);
            return this.returnError(error);
        }
    }
    async getByReceiptNo(receiptNo) {
        try {
            const transaction = await this.transactionService.getByReceiptNo(receiptNo);
            return this.returnSuccess(transaction);
        }
        catch (error) {
            this.logger.error(error);
            return this.returnError(error);
        }
    }
};
__decorate([
    (0, routing_controllers_1.Get)(),
    __param(0, (0, routing_controllers_1.QueryParams)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [phone_query_param_model_1.GetPhoneNumberQuery]),
    __metadata("design:returntype", Promise)
], TransactionController.prototype, "getByPhone", null);
__decorate([
    (0, routing_controllers_1.Get)("/receiptNo/:receiptNo"),
    __param(0, (0, routing_controllers_1.Param)("receiptNo")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TransactionController.prototype, "getByReceiptNo", null);
TransactionController = __decorate([
    (0, routing_controllers_1.JsonController)("/transactions"),
    (0, routing_controllers_1.Authorized)(),
    __metadata("design:paramtypes", [transaction_service_1.TransactionService, logger_1.Logger])
], TransactionController);
exports.TransactionController = TransactionController;
//# sourceMappingURL=transaction.controller.js.map