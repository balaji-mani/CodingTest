"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SqlConnection = void 0;
const typedi_1 = require("typedi");
const typeorm_1 = require("typeorm");
const collect_at_arrival_model_1 = require("../models/transaction-sync/collect-at-arrival.model");
const header_model_1 = require("../models/transaction-sync/header.model");
const payment_entry_model_1 = require("../models/transaction-sync/payment-entry.model");
const sales_entry_model_1 = require("../models/transaction-sync/sales-entry.model");
const webhook_model_1 = require("../models/webhook/webhook.model");
let SqlConnection = class SqlConnection {
    constructor() {
        (0, typeorm_1.createConnection)({
            type: "mssql",
            host: process.env.SQLSERVER_HOST,
            port: 1433,
            username: process.env.SQLSERVER_USERNAME,
            password: process.env.SQLSERVER_PASSWORD,
            database: process.env.SQLSERVER_NAME,
            entities: [collect_at_arrival_model_1.CollectAtArrivalData, header_model_1.HeaderData, payment_entry_model_1.PaymentEntryData, sales_entry_model_1.SalesEntryData, webhook_model_1.WebhookData],
            synchronize: true,
            logging: false,
        }).then(connection => {
            this.dbConnection = connection;
        });
        console.log("connected successfully");
    }
    catch(err) {
        console.log(err);
    }
};
SqlConnection = __decorate([
    (0, typedi_1.Service)(),
    __metadata("design:paramtypes", [])
], SqlConnection);
exports.SqlConnection = SqlConnection;
//# sourceMappingURL=db.js.map