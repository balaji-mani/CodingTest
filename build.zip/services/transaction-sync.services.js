"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionSyncService = void 0;
const typedi_1 = require("typedi");
const collect_at_arrival_repo_1 = require("../repository/collect-at-arrival.repo");
const sales_entry_repo_1 = require("../repository/sales-entry.repo");
const header_repo_1 = require("../repository/header.repo");
const payment_repo_1 = require("../repository/payment.repo");
const webhook_services_1 = require("./webhook.services");
const flight_detail_repo_1 = require("../repository/flight-detail.repo");
const product_info_repo_1 = require("../repository/product-info.repo");
let TransactionSyncService = class TransactionSyncService {
    constructor(collectAtArrivalRepo, salesEntryRepo, headerRepo, paymentRepo, flightDetailRepo, productInfoRepo, webhookService) {
        this.collectAtArrivalRepo = collectAtArrivalRepo;
        this.salesEntryRepo = salesEntryRepo;
        this.headerRepo = headerRepo;
        this.paymentRepo = paymentRepo;
        this.flightDetailRepo = flightDetailRepo;
        this.productInfoRepo = productInfoRepo;
        this.webhookService = webhookService;
    }
    async addCollectAtArrivals(collectAtArrivalData) {
        const results = await this.collectAtArrivalRepo.addCollectAtArrival(collectAtArrivalData);
        this.webhookService.publish(collectAtArrivalData);
        return results;
    }
    async addHeaders(headerData) {
        return this.headerRepo.addHeader(headerData);
    }
    async addSalesEntries(salesEntryData) {
        return this.salesEntryRepo.addSalesEntryRepo(salesEntryData);
    }
    async addPaymentEntries(paymentEntryData) {
        return this.paymentRepo.addPaymentEntries(paymentEntryData);
    }
    async addFlightDetails(flightDetails) {
        return this.flightDetailRepo.addFlightDetails(flightDetails);
    }
    async addProductInfo(productInfo) {
        return this.productInfoRepo.addProductInfo(productInfo);
    }
};
TransactionSyncService = __decorate([
    (0, typedi_1.Service)(),
    __metadata("design:paramtypes", [collect_at_arrival_repo_1.CollectAtArrivalRepo,
        sales_entry_repo_1.SalesEntryRepo,
        header_repo_1.HeaderRepo,
        payment_repo_1.PaymentRepo,
        flight_detail_repo_1.FlightDetailRepo,
        product_info_repo_1.ProductInfoRepo,
        webhook_services_1.WebhookService])
], TransactionSyncService);
exports.TransactionSyncService = TransactionSyncService;
//# sourceMappingURL=transaction-sync.services.js.map