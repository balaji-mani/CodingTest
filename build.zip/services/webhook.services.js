"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookService = void 0;
const typedi_1 = require("typedi");
const logger_1 = require("../common/logger/logger");
const webhook_repo_1 = require("../repository/webhook.repo");
const axios_1 = __importDefault(require("axios"));
let WebhookService = class WebhookService {
    constructor(webhookRepo, logger) {
        this.webhookRepo = webhookRepo;
        this.logger = logger;
    }
    async addWebhook(addWebhookData) {
        return await this.webhookRepo.add(addWebhookData);
    }
    async publish(collectAtArrivals) {
        const webhookRepoCollection = await this.webhookRepo.getAll();
        webhookRepoCollection.forEach((webhookSubscriber) => {
            for (const collectAtArrival of collectAtArrivals) {
                this.publishCollectArrivaldata(webhookSubscriber.webhookUrl, collectAtArrival);
            }
        });
    }
    async publishCollectArrivaldata(url, data) {
        var config = {
            method: "post",
            url: url,
            headers: {
                "Content-Type": "application/json",
            },
            data: JSON.stringify(data),
        };
        const result = await (0, axios_1.default)(config);
        return result;
    }
};
WebhookService = __decorate([
    (0, typedi_1.Service)(),
    __metadata("design:paramtypes", [webhook_repo_1.WebhookRepo, logger_1.Logger])
], WebhookService);
exports.WebhookService = WebhookService;
//# sourceMappingURL=webhook.services.js.map