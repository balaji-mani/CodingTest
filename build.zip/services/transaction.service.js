"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionService = void 0;
const typedi_1 = require("typedi");
const collect_at_arrival_repo_1 = require("../repository/collect-at-arrival.repo");
const sales_entry_repo_1 = require("../repository/sales-entry.repo");
const header_repo_1 = require("../repository/header.repo");
const payment_repo_1 = require("../repository/payment.repo");
const transactions_summary_model_1 = require("../models/transactions-summary.model");
let TransactionService = class TransactionService {
    constructor(collectAtArrivalRepo, salesEntryRepo, headerRepo, paymentRepo) {
        this.collectAtArrivalRepo = collectAtArrivalRepo;
        this.salesEntryRepo = salesEntryRepo;
        this.headerRepo = headerRepo;
        this.paymentRepo = paymentRepo;
    }
    async getByPhone(phone, pagingOptions) {
        const transactions = [];
        const result = await this.collectAtArrivalRepo.getByPhoneNumber(phone, pagingOptions);
        const totalCount = await this.getCountByPhoneNumber(phone);
        for (const collectAtArrival of result) {
            const transactionSummaryVm = new transactions_summary_model_1.TransactionSummaryViewModel();
            transactionSummaryVm.receiptNumber = collectAtArrival.receiptNo;
            const headerTransaction = await this.headerRepo.getByReceiptNo(transactionSummaryVm.receiptNumber);
            if (headerTransaction) {
                transactionSummaryVm.totalAmount = headerTransaction.payment;
                transactionSummaryVm.totalItems = Number(headerTransaction.noofItems);
                transactionSummaryVm.totalDiscount = headerTransaction.discountAmount;
            }
            transactions.push(transactionSummaryVm);
        }
        return {
            items: transactions,
            pageNumber: (pagingOptions === null || pagingOptions === void 0 ? void 0 : pagingOptions.pageNumber) || 0,
            totalItems: totalCount,
        };
    }
    async getByReceiptNo(receiptNo) {
        const transactionDetailVm = new transactions_summary_model_1.TransactionDetailViewModel();
        const paymentTransactions = await this.paymentRepo.getByReceiptNo(receiptNo);
        const collectAtArrival = await this.collectAtArrivalRepo.getByReceiptNo(receiptNo);
        const salesEntryTransactions = await this.salesEntryRepo.getByReceiptNo(receiptNo);
        const headerData = await this.headerRepo.getByReceiptNo(receiptNo);
        this.populateCustomerDetails(collectAtArrival, transactionDetailVm);
        this.populateHeaderDetails(headerData, transactionDetailVm);
        this.populateSalesTransactions(salesEntryTransactions, transactionDetailVm);
        this.populatePaymentTransactions(paymentTransactions, transactionDetailVm);
        return transactionDetailVm;
    }
    async getCountByPhoneNumber(phone) {
        return this.collectAtArrivalRepo.getCountByPhoneNumber(phone);
    }
    populateCustomerDetails(collectAtArrival, transactionDetailVm) {
        if (collectAtArrival) {
            transactionDetailVm.customerName = collectAtArrival.customerName;
            transactionDetailVm.customerEmail = collectAtArrival.customerEmail;
            transactionDetailVm.customerNumber = collectAtArrival.customerMobileNo;
            transactionDetailVm.receiptNumber = collectAtArrival.receiptNo;
            transactionDetailVm.transactionDate = collectAtArrival.transDate;
            transactionDetailVm.transactionTime = collectAtArrival.transTime;
        }
    }
    populateHeaderDetails(headerData, transactionDetailVm) {
        if (headerData) {
            transactionDetailVm.totalAmount = headerData.payment;
            transactionDetailVm.totalItems = Number(headerData.noofItems);
            transactionDetailVm.totalDiscount = headerData.discountAmount;
        }
    }
    populateSalesTransactions(salesTransactions, transactionDetailVm) {
        const salesEntryViewModels = [];
        for (const salesEntry of salesTransactions) {
            const salesEntryVm = Object.assign({}, salesEntry);
            salesEntryViewModels.push(salesEntryVm);
        }
        transactionDetailVm.salesEntries = salesEntryViewModels;
    }
    populatePaymentTransactions(paymentEntries, transactionDetailVm) {
        const paymentEntryViewModels = [];
        for (const paymentEntry of paymentEntries) {
            const paymentEntryVm = Object.assign({}, paymentEntry);
            paymentEntryViewModels.push(paymentEntryVm);
        }
        transactionDetailVm.paymentEntries = paymentEntryViewModels;
    }
};
TransactionService = __decorate([
    (0, typedi_1.Service)(),
    __metadata("design:paramtypes", [collect_at_arrival_repo_1.CollectAtArrivalRepo,
        sales_entry_repo_1.SalesEntryRepo,
        header_repo_1.HeaderRepo,
        payment_repo_1.PaymentRepo])
], TransactionService);
exports.TransactionService = TransactionService;
//# sourceMappingURL=transaction.service.js.map