"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaginatedCollection = void 0;
class PaginatedCollection {
}
exports.PaginatedCollection = PaginatedCollection;
//# sourceMappingURL=paginated-collection.model.js.map