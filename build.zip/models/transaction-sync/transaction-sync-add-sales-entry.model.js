"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddSalesEntryData = void 0;
const typeorm_1 = require("typeorm");
const entity_base_model_1 = require("../entity-base.model");
let AddSalesEntryData = class AddSalesEntryData extends entity_base_model_1.BaseEntity {
};
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "receiptNo", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "transTime", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "transDate", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "itemNo", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "quantity", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "netAmount", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "storeNo", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "pOSTerminalNo", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "divisionCode", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "drandDescription", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "discountAmount", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "netPrice", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "periodicDiscGroup", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "periodicDiscount", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "price", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "quantityForShopnCollect", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "shiftDate", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "shiftNo", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "staffID", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "standardNetPrice", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "totalRoundedAmt", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "markforShopnCollect", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], AddSalesEntryData.prototype, "vATCode", void 0);
AddSalesEntryData = __decorate([
    typeorm_1.Entity()
], AddSalesEntryData);
exports.AddSalesEntryData = AddSalesEntryData;
//# sourceMappingURL=transaction-sync-add-sales-entry.model.js.map