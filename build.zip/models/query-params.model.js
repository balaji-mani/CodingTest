"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryParams = void 0;
class QueryParams {
}
exports.QueryParams = QueryParams;
//# sourceMappingURL=query-params.model.js.map