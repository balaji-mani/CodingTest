"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesEntryViewModel = exports.PaymentEntryViewModel = exports.HeaderDataViewModel = exports.TransactionDetailViewModel = exports.TransactionSummaryViewModel = void 0;
class TransactionSummaryViewModel {
}
exports.TransactionSummaryViewModel = TransactionSummaryViewModel;
class TransactionDetailViewModel {
}
exports.TransactionDetailViewModel = TransactionDetailViewModel;
class HeaderDataViewModel {
}
exports.HeaderDataViewModel = HeaderDataViewModel;
class PaymentEntryViewModel {
}
exports.PaymentEntryViewModel = PaymentEntryViewModel;
class SalesEntryViewModel {
}
exports.SalesEntryViewModel = SalesEntryViewModel;
//List
// [
// 	{
// 		'receiptNumber': 2819381938138,
// 		'totalAmount': '',
// 		'transactionDate': ''
// 	},
// 	{
// 		'receiptNumber': 2819381938138,
// 		'totalAmount': '',
// 		'transactionDate': ''
// 	},
// 	{
// 		'receiptNumber': 2819381938138,
// 		'totalAmount': '',
// 		'transactionDate': ''
// 	},
// 	{
// 		'receiptNumber': 2819381938138,
// 		'totalAmount': '',
// 		'transactionDate': ''
// 	}
// ]
//Details
// {
//     'receiptNumber': 2819381938138,
//     'totalAmount': '',
//     'transactionDate': ''
//     'customerName': '',
//     'customerNumber': ''
//     'items' [ //Sales entry (1 : many)
//         {
//             'itemName': 'Grants'
//         },
//         {
//             'itemName': 'BH'
//         }
//     ],
//     'paymentEntries': [  //Payment entry (1 : many)
//         {
//             'currency': '',
//             'paymentType': 'cash | CC | other'
//         },
//         {
//             'currency': '',
//             'paymentType': 'cash | CC | other'
//         }
//     ]
// }
//# sourceMappingURL=transactions-summary.model.js.map