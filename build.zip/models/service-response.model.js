"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceResponse = void 0;
class ServiceResponse {
}
exports.ServiceResponse = ServiceResponse;
//# sourceMappingURL=service-response.model.js.map