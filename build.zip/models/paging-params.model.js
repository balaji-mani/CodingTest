"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PagingParams = void 0;
class PagingParams {
}
exports.PagingParams = PagingParams;
//# sourceMappingURL=paging-params.model.js.map